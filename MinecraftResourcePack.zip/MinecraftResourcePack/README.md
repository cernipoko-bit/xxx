# Minecraft Resource Pack Template

## Structure
```
MinecraftResourcePack/
├── pack.mcmeta              # Required metadata file
├── assets/
│   └── minecraft/
│       ├── textures/         # Texture files (.png)
│       │   ├── block/       # Block textures
│       │   ├── item/        # Item textures
│       │   ├── entity/      # Entity textures
│       │   └── ...
│       ├── models/          # JSON model files
│       │   ├── block/       # Block models
│       │   ├── item/        # Item models
│       │   └── ...
│       ├── sounds/          # Sound files (.ogg)
│       ├── lang/            # Language files (.json)
│       └── ...
└── README.md               # This file
```

## Usage
1. Place your texture files in `assets/minecraft/textures/`
2. Place your model files in `assets/minecraft/models/`
3. Place your sound files in `assets/minecraft/sounds/`
4. Place language files in `assets/minecraft/lang/`
5. Copy the entire folder to your Minecraft resource packs directory

## Common Paths
- Block textures: `assets/minecraft/textures/block/`
- Item textures: `assets/minecraft/textures/item/`
- Block models: `assets/minecraft/models/block/`
- Item models: `assets/minecraft/models/item/`
- Language files: `assets/minecraft/lang/`

## Notes
- `pack_format: 48` is for Minecraft 1.20.2+
- Adjust `pack_format` for different Minecraft versions
- All textures must be 16x16, 32x32, 64x64, 128x128, 256x256, or 512x512 pixels
- Models use JSON format
- Sounds must be in .ogg format
